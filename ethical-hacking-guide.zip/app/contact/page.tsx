import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Mail, MapPin, Phone } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function ContactPage() {
  return (
    <div className="min-h-screen text-white">
      <Navbar />

      <main>
        <section className="py-12 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-12">
                <h1 className="text-3xl md:text-4xl font-bold mb-4">Get in Touch</h1>
                <p className="text-zinc-300 max-w-2xl mx-auto">
                  Have questions about our educational resources? Want to suggest a topic for a future guide? We'd love
                  to hear from you.
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8 mb-12">
                <div className="bg-zinc-900/70 p-6 rounded-lg border border-zinc-800 text-center">
                  <div className="bg-emerald-900/20 h-12 w-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="h-6 w-6 text-emerald-400" />
                  </div>
                  <h3 className="font-bold mb-2">Email</h3>
                  <p className="text-zinc-400 text-sm mb-4">For general inquiries and support</p>
                  <a href="mailto:contact@ethicalhackingguides.com" className="text-emerald-400 hover:text-emerald-300">
                    contact@ethicalhackingguides.com
                  </a>
                </div>

                <div className="bg-zinc-900/70 p-6 rounded-lg border border-zinc-800 text-center">
                  <div className="bg-emerald-900/20 h-12 w-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="h-6 w-6 text-emerald-400" />
                  </div>
                  <h3 className="font-bold mb-2">Phone</h3>
                  <p className="text-zinc-400 text-sm mb-4">Monday-Friday, 9am-5pm EST</p>
                  <a href="tel:+1234567890" className="text-emerald-400 hover:text-emerald-300">
                    +1 (234) 567-890
                  </a>
                </div>

                <div className="bg-zinc-900/70 p-6 rounded-lg border border-zinc-800 text-center">
                  <div className="bg-emerald-900/20 h-12 w-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="h-6 w-6 text-emerald-400" />
                  </div>
                  <h3 className="font-bold mb-2">Location</h3>
                  <p className="text-zinc-400 text-sm mb-4">Our educational office</p>
                  <p className="text-emerald-400">
                    123 Cyber Street
                    <br />
                    Tech City, TC 12345
                  </p>
                </div>
              </div>

              <div className="bg-zinc-900/70 rounded-lg border border-zinc-800 overflow-hidden">
                <div className="grid md:grid-cols-2">
                  <div className="p-8">
                    <h2 className="text-2xl font-bold mb-6">Send a Message</h2>
                    <form className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="first-name" className="text-sm font-medium">
                            First name
                          </label>
                          <Input
                            id="first-name"
                            placeholder="John"
                            className="bg-zinc-800/70 border-zinc-700 text-white"
                          />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="last-name" className="text-sm font-medium">
                            Last name
                          </label>
                          <Input
                            id="last-name"
                            placeholder="Doe"
                            className="bg-zinc-800/70 border-zinc-700 text-white"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email
                        </label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="john.doe@example.com"
                          className="bg-zinc-800/70 border-zinc-700 text-white"
                        />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="subject" className="text-sm font-medium">
                          Subject
                        </label>
                        <Input
                          id="subject"
                          placeholder="How can we help you?"
                          className="bg-zinc-800/70 border-zinc-700 text-white"
                        />
                      </div>

                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">
                          Message
                        </label>
                        <Textarea
                          id="message"
                          placeholder="Your message here..."
                          className="min-h-[120px] bg-zinc-800/70 border-zinc-700 text-white"
                        />
                      </div>

                      <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Send Message</Button>
                    </form>
                  </div>

                  <div className="bg-zinc-800/70 p-8 flex items-center">
                    <div>
                      <h3 className="text-xl font-bold mb-4">Educational Purpose Statement</h3>
                      <p className="text-zinc-300 mb-6">
                        Ethical Hacking Guides is dedicated to providing educational resources for students interested
                        in cybersecurity and ethical hacking. Our content is designed for educational purposes only.
                      </p>
                      <div className="space-y-4">
                        <div className="flex items-start">
                          <div className="bg-emerald-900/20 h-8 w-8 rounded-full flex items-center justify-center mr-3 mt-0.5">
                            <span className="text-emerald-400 font-bold">1</span>
                          </div>
                          <p className="text-zinc-300 text-sm">
                            All techniques should only be practiced in controlled, authorized environments.
                          </p>
                        </div>
                        <div className="flex items-start">
                          <div className="bg-emerald-900/20 h-8 w-8 rounded-full flex items-center justify-center mr-3 mt-0.5">
                            <span className="text-emerald-400 font-bold">2</span>
                          </div>
                          <p className="text-zinc-300 text-sm">
                            We promote ethical behavior and responsible use of security knowledge.
                          </p>
                        </div>
                        <div className="flex items-start">
                          <div className="bg-emerald-900/20 h-8 w-8 rounded-full flex items-center justify-center mr-3 mt-0.5">
                            <span className="text-emerald-400 font-bold">3</span>
                          </div>
                          <p className="text-zinc-300 text-sm">
                            Our goal is to help build a more secure digital world through education.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Educational disclaimer */}
        <section className="py-8 cyber-gradient">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto p-6 border border-emerald-900/30 rounded-lg bg-black/50">
              <h3 className="text-lg font-bold text-emerald-400 mb-2">Educational Disclaimer</h3>
              <p className="text-zinc-300 text-sm">
                This website is provided for educational purposes only. The techniques described should only be
                practiced in controlled, authorized environments. Unauthorized scanning or testing of systems is illegal
                and unethical. Always obtain proper permission before performing any security testing. Created by
                Sebastian Dino for educational use only.
              </p>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

