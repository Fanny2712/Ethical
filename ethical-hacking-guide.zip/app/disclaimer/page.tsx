import Link from "next/link"
import { ArrowLeft, AlertTriangle, CheckCircle, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"

export default function DisclaimerPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      <main className="py-12 md:py-24">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <Link href="/" className="inline-flex items-center text-emerald-400 hover:text-emerald-300 mb-8">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to home
            </Link>

            <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-8">
              <div className="flex items-center gap-3 mb-6">
                <AlertTriangle className="h-8 w-8 text-amber-500" />
                <h1 className="text-3xl font-bold">Educational Disclaimer</h1>
              </div>

              <div className="prose prose-invert max-w-none">
                <p className="text-lg mb-6">
                  This website and all its content, created by Sebastian Dino, is provided strictly for
                  <strong className="text-amber-400"> educational purposes only</strong>.
                </p>

                <h2>Purpose of This Website</h2>
                <p>
                  The purpose of this website is to provide educational resources about ethical hacking and
                  cybersecurity concepts for students and individuals interested in learning about these topics in a
                  responsible manner. All information is presented with the intent to educate and improve understanding
                  of security concepts.
                </p>

                <h2>Ethical Use of Knowledge</h2>
                <p>
                  The techniques, tools, and concepts described on this website should only be practiced in controlled,
                  authorized environments such as:
                </p>
                <ul>
                  <li>Personal lab environments</li>
                  <li>Systems you own</li>
                  <li>Systems for which you have explicit permission to test</li>
                  <li>Educational environments set up for learning purposes</li>
                </ul>

                <h2>Legal Considerations</h2>
                <p>
                  Unauthorized testing of systems, networks, or applications is illegal in most jurisdictions and may
                  result in severe legal consequences. This includes but is not limited to:
                </p>
                <ul>
                  <li>Unauthorized access to computer systems</li>
                  <li>Network scanning without permission</li>
                  <li>Attempting to bypass security measures without authorization</li>
                  <li>Any form of denial of service testing without explicit permission</li>
                </ul>

                <h2>Our Commitment</h2>
                <p>
                  We are committed to promoting ethical behavior in the field of cybersecurity. Our goal is to help
                  build a more secure digital world by educating future security professionals about both offensive and
                  defensive security concepts in a responsible manner.
                </p>

                <div className="bg-zinc-800 p-6 rounded-lg my-8 border-l-4 border-emerald-500">
                  <h3 className="flex items-center text-emerald-400 mb-2">
                    <CheckCircle className="h-5 w-5 mr-2" /> Responsible Disclosure
                  </h3>
                  <p className="mb-0">
                    If you discover security vulnerabilities through the knowledge gained from this website, please
                    practice responsible disclosure by reporting them to the appropriate parties through proper
                    channels, such as official vulnerability disclosure programs.
                  </p>
                </div>

                <h2>Acknowledgment</h2>
                <p>By using this website, you acknowledge that:</p>
                <ul>
                  <li>You will only use the information for legal and ethical purposes</li>
                  <li>You understand the potential legal consequences of misusing this information</li>
                  <li>You will practice security testing only on systems you own or have permission to test</li>
                  <li>You will respect the privacy and security of others</li>
                </ul>

                <div className="text-center mt-8 pt-8 border-t border-zinc-800">
                  <div className="inline-block bg-zinc-800 p-3 rounded-full mb-4">
                    <Shield className="h-8 w-8 text-emerald-500" />
                  </div>
                  <p className="text-lg font-medium">Created by Sebastian Dino for educational purposes only</p>
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                <Link href="/">Return to Homepage</Link>
              </Button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

