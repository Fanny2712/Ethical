import Image from "next/image"
import { Shield, Code } from "lucide-react"
import Navbar from "@/components/navbar"
import Footer from "@/components/footer"
import FeatureCard from "@/components/feature-card"
import HeroSection from "@/components/hero-section"

export default function Home() {
  return (
    <div className="min-h-screen text-white">
      <Navbar />

      <HeroSection />

      {/* About Section */}
      <section id="about" className="py-16 cyber-gradient">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">About This Resource</h2>
              <p className="text-zinc-300 mb-6">
                Welcome to this educational platform created by Sebastian Dino. This website is designed exclusively for
                educational purposes to help students understand cybersecurity concepts and ethical hacking
                methodologies in a safe, legal, and responsible manner.
              </p>
              <p className="text-zinc-300 mb-6">
                All techniques and tools discussed here should only be practiced in controlled environments with proper
                authorization. The knowledge shared here aims to help future cybersecurity professionals protect systems
                rather than exploit them.
              </p>
              <div className="p-4 bg-zinc-800/50 border border-emerald-900/30 rounded-lg">
                <p className="text-emerald-400 font-medium">Educational Disclaimer:</p>
                <p className="text-zinc-300 text-sm">
                  This resource is created strictly for educational purposes. Unauthorized testing of security systems
                  is illegal and unethical. Always practice in authorized environments only.
                </p>
              </div>
            </div>
            <div className="md:w-1/2">
              <div className="relative rounded-lg overflow-hidden shadow-xl border border-zinc-800">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  alt="Cybersecurity Education"
                  width={600}
                  height={400}
                  className="object-cover"
                  // Replace with a free image from Unsplash/Pexels/Pixabay showing students learning or cybersecurity concept
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent flex items-end">
                  <div className="p-6">
                    <p className="text-lg font-medium">Created by Sebastian Dino</p>
                    <p className="text-zinc-300">For educational purposes only</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 cyber-grid">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Learning Modules</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <FeatureCard
              icon={<Shield className="h-10 w-10 text-emerald-500" />}
              title="Network Security"
              description="Learn the fundamentals of network security, including protocols, common vulnerabilities, and protection mechanisms."
              link="#"
              imageSrc="/placeholder.svg?height=200&width=400"
              // Replace with: "https://unsplash.com/photos/computer-network-cables-in-server-room"
            />
            <FeatureCard
              icon={<Code className="h-10 w-10 text-emerald-500" />}
              title="Web Security"
              description="Explore common web vulnerabilities like XSS and SQL injection, and learn how to secure web applications."
              link="#"
              imageSrc="/placeholder.svg?height=200&width=400"
              // Replace with: "https://unsplash.com/photos/person-typing-on-computer-keyboard"
            />
          </div>
        </div>
      </section>

      {/* Latest Guides Section */}
      <section className="py-16 cyber-dots">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8">Latest Guides</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Understanding Port Scanning",
                description:
                  "Learn about different port scanning techniques and how they're used in security assessments.",
                image: "/placeholder.svg?height=200&width=400",
                // Replace with: "https://unsplash.com/photos/network-security-concept"
                date: "March 10, 2023",
                category: "Network Security",
              },
              {
                title: "Secure Coding Practices",
                description:
                  "Discover how to write code that's resistant to common security vulnerabilities and attacks.",
                image: "/placeholder.svg?height=200&width=400",
                // Replace with: "https://unsplash.com/photos/secure-coding-concept"
                date: "February 28, 2023",
                category: "Web Security",
              },
              {
                title: "Introduction to Cryptography",
                description:
                  "Explore the basics of encryption, hashing, and how cryptography protects digital information.",
                image: "/placeholder.svg?height=200&width=400",
                // Replace with: "https://unsplash.com/photos/cryptography-concept"
                date: "February 15, 2023",
                category: "Security Fundamentals",
              },
            ].map((guide, index) => (
              <div key={index} className="group">
                <div className="bg-zinc-900/70 rounded-lg overflow-hidden border border-zinc-800 transition-all duration-300 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/10">
                  <div className="relative h-48">
                    <Image src={guide.image || "/placeholder.svg"} alt={guide.title} fill className="object-cover" />
                    <div className="absolute top-3 right-3 bg-black/70 text-xs font-medium px-2 py-1 rounded">
                      {guide.category}
                    </div>
                  </div>
                  <div className="p-5">
                    <p className="text-xs text-zinc-400 mb-2">{guide.date}</p>
                    <h3 className="text-xl font-bold mb-2 group-hover:text-emerald-400 transition-colors">
                      {guide.title}
                    </h3>
                    <p className="text-zinc-300 text-sm mb-4">{guide.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Educational disclaimer */}
      <section className="py-8 cyber-gradient">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto p-6 border border-emerald-900/30 rounded-lg bg-black/50">
            <h3 className="text-lg font-bold text-emerald-400 mb-2">Educational Disclaimer</h3>
            <p className="text-zinc-300 text-sm">
              This website is provided for educational purposes only. The techniques described should only be practiced
              in controlled, authorized environments. Unauthorized scanning or testing of systems is illegal and
              unethical. Always obtain proper permission before performing any security testing. Created by Sebastian
              Dino for educational use only.
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  )
}

