import Image from "next/image"
import type { ReactNode } from "react"

interface FeatureCardProps {
  icon: ReactNode
  title: string
  description: string
  link: string
  imageSrc?: string
}

export default function FeatureCard({ icon, title, description, imageSrc }: FeatureCardProps) {
  return (
    <div className="bg-zinc-900/70 p-6 rounded-lg border border-zinc-800 h-full transition-all duration-300 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-500/10">
      <div className="bg-black/50 p-3 rounded-full inline-block mb-4">{icon}</div>
      <h3 className="text-xl font-bold mb-2 transition-colors">{title}</h3>
      {imageSrc && (
        <div className="relative h-32 mb-3 rounded-md overflow-hidden">
          <Image src={imageSrc || "/placeholder.svg"} alt={title} fill className="object-cover" />
        </div>
      )}
      <p className="text-zinc-400 mb-4">{description}</p>
    </div>
  )
}

