export default function HeroSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      {/* Background with overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[#050505]"></div>
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fillRule='evenodd'%3E%3Cg fill='%2303a86b' fillOpacity='0.15'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#050505]"></div>

        {/* Matrix-like code rain effect */}
        <div className="absolute inset-0 overflow-hidden opacity-10">
          {Array.from({ length: 10 }).map((_, i) => (
            <div
              key={i}
              className="absolute matrix-animate"
              style={{
                left: `${i * 10}%`,
                top: 0,
                fontSize: "10px",
                color: "#03a86b",
                writingMode: "vertical-rl",
                textOrientation: "upright",
                letterSpacing: "5px",
                animation: `matrix-fade ${3 + (i % 3)}s infinite`,
                animationDelay: `${i * 0.2}s`,
              }}
            >
              01010111010001010100001001010011010010010101010001000101
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            <span className="text-emerald-500">Ethical Hacking</span> Guides <br />
            By Sebastian Dino
          </h1>
          <p className="text-xl text-zinc-300 mb-8 max-w-2xl">
            Learn cybersecurity and ethical hacking through practical, educational guides designed for students. Build
            your skills responsibly with our comprehensive resources.
          </p>

          <div className="p-4 bg-zinc-900/80 backdrop-blur-sm border border-emerald-900/30 rounded-lg inline-block">
            <p className="text-zinc-400 text-sm">
              Created by <span className="text-emerald-400 font-medium">Sebastian Dino</span> for educational purposes
              only
            </p>
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-[#050505] to-transparent"></div>
    </section>
  )
}

