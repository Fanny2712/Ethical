/**
 * Free Image Sources for Cybersecurity Website
 *
 * This file provides guidance on where to find free images for the website.
 * Replace the placeholder.svg references with actual images from these sources.
 */

export const imageSources = {
  // Free image sources for cybersecurity and technology
  sources: [
    {
      name: "Unsplash",
      url: "https://unsplash.com/",
      license: "Free to use under the Unsplash License",
      categories: [
        { name: "Cybersecurity", url: "https://unsplash.com/s/photos/cybersecurity" },
        { name: "Hacking", url: "https://unsplash.com/s/photos/hacking" },
        { name: "Technology", url: "https://unsplash.com/s/photos/technology" },
        { name: "Code", url: "https://unsplash.com/s/photos/code" },
        { name: "Network", url: "https://unsplash.com/s/photos/network" },
      ],
    },
    {
      name: "Pexels",
      url: "https://www.pexels.com/",
      license: "Free to use",
      categories: [
        { name: "Cybersecurity", url: "https://www.pexels.com/search/cybersecurity/" },
        { name: "Technology", url: "https://www.pexels.com/search/technology/" },
        { name: "Computer", url: "https://www.pexels.com/search/computer/" },
      ],
    },
    {
      name: "Pixabay",
      url: "https://pixabay.com/",
      license: "Free for commercial use, no attribution required",
      categories: [
        { name: "Cybersecurity", url: "https://pixabay.com/images/search/cyber%20security/" },
        { name: "Hacker", url: "https://pixabay.com/images/search/hacker/" },
        { name: "Technology", url: "https://pixabay.com/images/search/technology/" },
      ],
    },
  ],

  // Recommended images for specific sections
  recommendations: {
    hero: [
      "https://unsplash.com/photos/blue-and-purple-digital-wallpaper-4Mw7nkQDByk",
      "https://www.pexels.com/photo/person-using-laptop-computer-during-night-time-169573/",
      "https://pixabay.com/illustrations/hacker-cyber-crime-internet-2300772/",
    ],
    about: [
      "https://unsplash.com/photos/person-writing-on-computer-keyboard-npxXWgQ33ZQ",
      "https://www.pexels.com/photo/close-up-photo-of-programming-of-codes-546819/",
    ],
    networkSecurity: [
      "https://unsplash.com/photos/blue-and-white-light-in-dark-room-3GZNPBLImWc",
      "https://pixabay.com/photos/technology-network-computer-server-4816658/",
    ],
    webSecurity: [
      "https://unsplash.com/photos/person-using-macbook-pro-on-table-52jRtc2S_VE",
      "https://www.pexels.com/photo/close-up-photo-of-matrix-background-1089438/",
    ],
    systemSecurity: [
      "https://unsplash.com/photos/black-and-white-computer-keyboard-pHANr-CpbYM",
      "https://pixabay.com/photos/hacker-cyber-crime-computer-internet-1944688/",
    ],
    securityTools: [
      "https://unsplash.com/photos/black-flat-screen-computer-monitor-m_HRfLhgABo",
      "https://www.pexels.com/photo/black-and-gray-mining-rig-1148820/",
    ],
  },

  // How to use these images in the website
  usage: `
    1. Download the images from the sources above
    2. Place them in the public folder of your Next.js project
    3. Replace the placeholder.svg references with the actual image paths
    
    Example:
    <Image 
      src="/images/hero-background.jpg" 
      alt="Cybersecurity background" 
      fill
      className="object-cover"
    />
  `,
}

