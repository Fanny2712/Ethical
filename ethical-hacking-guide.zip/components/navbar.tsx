"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Shield, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const scrollToAbout = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault()
    const aboutSection = document.getElementById("about")
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth" })
      setIsMenuOpen(false)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-zinc-800 bg-black/80 backdrop-blur-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-emerald-500" />
            <span className="font-bold text-xl">Ethical Hacking Guides</span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium hover:text-emerald-400 transition-colors">
              Home
            </Link>
            <a
              href="#about"
              onClick={scrollToAbout}
              className="text-sm font-medium hover:text-emerald-400 transition-colors cursor-pointer"
            >
              About
            </a>
            <Link href="/contact" className="text-sm font-medium hover:text-emerald-400 transition-colors">
              Contact
            </Link>
          </nav>

          <div className="hidden md:flex items-center">
            <span className="text-xs text-zinc-400">Educational Content Only</span>
          </div>

          <button className="md:hidden flex items-center justify-center" onClick={toggleMenu} aria-label="Toggle menu">
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className={cn(
          "md:hidden fixed inset-x-0 top-16 bg-black border-b border-zinc-800 transition-all duration-300 ease-in-out",
          isMenuOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0 pointer-events-none",
        )}
      >
        <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
          <Link
            href="/"
            className="flex items-center gap-2 p-2 hover:bg-zinc-900 rounded-md"
            onClick={() => setIsMenuOpen(false)}
          >
            Home
          </Link>
          <a href="#about" className="flex items-center gap-2 p-2 hover:bg-zinc-900 rounded-md" onClick={scrollToAbout}>
            About
          </a>
          <Link
            href="/contact"
            className="flex items-center gap-2 p-2 hover:bg-zinc-900 rounded-md"
            onClick={() => setIsMenuOpen(false)}
          >
            Contact
          </Link>

          <div className="flex flex-col gap-2 pt-2 border-t border-zinc-800">
            <span className="text-xs text-zinc-400 p-2">Educational Content Only</span>
          </div>
        </div>
      </div>
    </header>
  )
}

